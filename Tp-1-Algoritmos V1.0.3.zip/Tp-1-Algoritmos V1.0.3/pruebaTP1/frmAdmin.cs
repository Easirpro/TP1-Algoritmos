﻿using System;
using System.Data;          // Nuevo: Para DataTable y OleDb
using System.Data.OleDb;    // Nuevo: Para OleDbConnection, etc.
using System.Windows.Forms;

namespace pruebaTP1
{
    public partial class frmAdmin : Form
    {
        bool esNuevo = false;
        string nombreUsuarioLogueado;
        string rolUsuarioLogueado;

        public frmAdmin(string nombreUsuario, string rolUsuario)
        {
            InitializeComponent();
            nombreUsuarioLogueado = nombreUsuario;
            rolUsuarioLogueado = rolUsuario;

            CargarUsuariosDesdeDB();
            cmbListUser.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            cmbListUser.SelectedIndex = 0;

            MostrarDatos();
            HabilitarEdicion(false);
        }

        private void CargarUsuariosDesdeDB()
        {
            using var conexion = new DBAccess().GetConnection();
            {
                conexion.Open();
                string consulta = "SELECT nombre FROM datos";
                OleDbCommand comando = new OleDbCommand(consulta, conexion);
                OleDbDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    cmbListUser.Items.Add(reader["nombre"].ToString());
                }
            }
        }

        private void MostrarDatos()
        {
            if (cmbListUser.SelectedItem == null) return;
            string selectedNombre = cmbListUser.SelectedItem.ToString();

            // Nuevo: Consultar datos desde Access
            using var conexion = new DBAccess().GetConnection();
            {
                conexion.Open();
                string consulta = "SELECT * FROM datos WHERE nombre = ?";
                OleDbCommand comando = new OleDbCommand(consulta, conexion);
                comando.Parameters.AddWithValue("?", selectedNombre);

                OleDbDataReader reader = comando.ExecuteReader();
                if (reader.Read())
                {
                    txtNombre.Text = reader["nombre"].ToString();
                    txtApellido.Text = reader["apellido"].ToString();
                    txtDni.Text = reader["dni"].ToString();
                    txtTelefono.Text = reader["telefono"].ToString();
                    txtEmail.Text = reader["email"].ToString();
                    string rol = reader["Rol"].ToString();
                    rdbAdmin.Checked = (rol == "Administrador");
                    rdbUser.Checked = (rol == "Usuario");
                    // Lógica de contraseña: solo mostrar si es el usuario logueado
                    if (selectedNombre == nombreUsuarioLogueado && rolUsuarioLogueado == rol)
                    {
                        txtPasswordUsuario.Text = reader["password"].ToString();
                        txtPasswordUsuario.ReadOnly = false;
                    }
                    else
                    {
                        txtPasswordUsuario.Text = "******";
                        txtPasswordUsuario.ReadOnly = true;
                    }
                }
            }
        }

        private void HabilitarEdicion(bool habilitar)
        {
            txtNombre.ReadOnly = !habilitar;
            txtApellido.ReadOnly = !habilitar;
            txtDni.ReadOnly = !habilitar;
            txtTelefono.ReadOnly = !habilitar;
            txtEmail.ReadOnly = !habilitar;
            rdbUser.Enabled = habilitar;
            rdbAdmin.Enabled = habilitar;
            BtnSave.Enabled = habilitar;
            btnCancelar.Enabled = habilitar;
            if (esNuevo)  txtPasswordUsuario.ReadOnly = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MostrarDatos();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtApellido.Text) ||
                string.IsNullOrWhiteSpace(txtDni.Text) || string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(txtPasswordUsuario.Text))
            {
                MessageBox.Show("Todos los campos son obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!long.TryParse(txtDni.Text, out _) || !long.TryParse(txtTelefono.Text, out _))
            {
                MessageBox.Show("El DNI y el Teléfono deben ser numéricos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (txtDni.Text.Length != 8)
            {
                MessageBox.Show("El DNI debe tener 8 dígitos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (txtTelefono.Text.Length < 8 || txtTelefono.Text.Length > 10)
            {
                MessageBox.Show("El Teléfono debe tener entre 8 a 10 dígitos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string email = txtEmail.Text.Trim();
            if (!email.Contains("@") || email.Length < 5)
            {
                MessageBox.Show("El email debe tener un formato válido (ej: usuario@dominio.com).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedNombre = cmbListUser.SelectedItem.ToString();
            string rol = rdbAdmin.Checked ? "Administrador" : "Usuario";

            using var conexion = new DBAccess().GetConnection();
            {
                conexion.Open();
                if (esNuevo)
                {
                    // Nuevo: Chequear si DNI ya existe
                    string checkDni = "SELECT COUNT(*) FROM datos WHERE dni = ?";
                    OleDbCommand checkCmd = new OleDbCommand(checkDni, conexion);
                    checkCmd.Parameters.AddWithValue("?", txtDni.Text);
                    int count = (int)checkCmd.ExecuteScalar();
                    if (count > 0)
                    {
                        MessageBox.Show("Ya existe un usuario con ese DNI.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    // Nuevo: INSERT para usuario nuevo
                    string insertQuery = "INSERT INTO datos (nombre, apellido, dni, telefono, email, [password], Rol) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    OleDbCommand insertCmd = new OleDbCommand(insertQuery, conexion);
                    insertCmd.Parameters.AddWithValue("?", txtNombre.Text);
                    insertCmd.Parameters.AddWithValue("?", txtApellido.Text);
                    insertCmd.Parameters.AddWithValue("?", txtDni.Text);
                    insertCmd.Parameters.AddWithValue("?", txtTelefono.Text);
                    insertCmd.Parameters.AddWithValue("?", txtEmail.Text);
                    insertCmd.Parameters.AddWithValue("?", txtPasswordUsuario.Text);
                    insertCmd.Parameters.AddWithValue("?", rol);
                    insertCmd.ExecuteNonQuery();
                    // Actualizar ComboBox
                    cmbListUser.Items.Add(txtNombre.Text);
                    cmbListUser.SelectedItem = txtNombre.Text;
                    esNuevo = false;
                }
                else
                {
                    // Nuevo: UPDATE para usuario existente
                    string updateQuery = "UPDATE datos SET nombre = ?, apellido = ?, telefono = ?, email = ?, [password] = ?, Rol = ? WHERE nombre = ?";
                    OleDbCommand updateCmd = new OleDbCommand(updateQuery, conexion);

                    updateCmd.Parameters.AddWithValue("?", txtNombre.Text);
                    updateCmd.Parameters.AddWithValue("?", txtApellido.Text);
                    updateCmd.Parameters.AddWithValue("?", txtTelefono.Text);
                    updateCmd.Parameters.AddWithValue("?", txtEmail.Text);
                    updateCmd.Parameters.AddWithValue("?", txtPasswordUsuario.Text);
                    updateCmd.Parameters.AddWithValue("?", rol);
                    updateCmd.Parameters.AddWithValue("?", selectedNombre); // WHERE usa el nombre original
                    updateCmd.ExecuteNonQuery();

                    // Si cambió el nombre, actualizar ComboBox
                    if (txtNombre.Text != selectedNombre)
                    {
                        int index = cmbListUser.Items.IndexOf(selectedNombre);
                        if (index != -1)
                        {
                            cmbListUser.Items[index] = txtNombre.Text;
                        }
                    }
                }
            }

            HabilitarEdicion(false);
            MessageBox.Show("Datos guardados correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            MostrarDatos();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            HabilitarEdicion(true);
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Limpiar campos para nuevo usuario
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtDni.Text = "";
            txtTelefono.Text = "";
            txtEmail.Text = "";
            txtPasswordUsuario.Text = "";
            rdbUser.Checked = true;
            rdbAdmin.Checked = false;
            HabilitarEdicion(true);
            esNuevo = true;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

            esNuevo = false;
            if (cmbListUser.Items.Count > 0) cmbListUser.SelectedIndex = 0;
            MostrarDatos();
            HabilitarEdicion(false);
        }

        private void lblTituloUsuario_Click(object sender, EventArgs e)
        {

        }
    }
}

