﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace pruebaTP1
{
    public partial class frmRecover : Form
    {
        string correoVerificado;

        public frmRecover()
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyDown += frmRecover_Keydown;
        }
        private void frmRecover_Keydown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }
        private void MostrarError(string mensaje)
        {
            lblError.Text = mensaje;
            lblError.ForeColor = Color.Red;
            lblError.Visible = true;
        }

        private void btnEnviarCodigo_Click(object sender, EventArgs e)
        {
            string correo = txtCorreo.Text.Trim();

            if (string.IsNullOrEmpty(correo))
            {
                MostrarError("Por favor, ingrese su correo.");
                return;
            }

            if (!correo.Contains("@") || correo.Length < 5){
                MostrarError("El email debe tener un formato válido (ej: usuario@dominio.com).");
                return;
            }
            
            using (var conexion = new DBAccess().GetConnection())
            {
                conexion.Open();

                string consulta = "SELECT COUNT(*) FROM datos WHERE email = ?";
                OleDbCommand comando = new OleDbCommand(consulta, conexion);
                comando.Parameters.AddWithValue("?", correo);

                int count = (int)comando.ExecuteScalar();

                conexion.Close();

                if (count == 0)
                {
                    MostrarError("El correo no está registrado.");
                    return;
                }
            }

            correoVerificado = correo;

            lblCodigoIngresar.Visible = true;
            txtCodigo.Visible = true;
            btnVerificarCodigo.Visible = true;
        }

        private void btnVerificarCodigo_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            string codigo = txtCodigo.Text.Trim();

            if (string.IsNullOrWhiteSpace(codigo))
            {
                MostrarError("Por favor, ingrese el codigo enviado.");
                return;
            }

            if (codigo != "1234")
            {
                MostrarError("El codigo es incorrecto");
                return;
            }

            lblnewPass.Visible = true;
            txtnewPass.Visible = true;
            lblconfirmar.Visible = true;
            txtconfirmar.Visible = true;
            btnconfirmar.Visible = true;
        }

        private void btnconfirmar_Click_1(object sender, EventArgs e)
        {
            string nuevaPass = txtnewPass.Text;
            string confirmarPass = txtconfirmar.Text;

            if (string.IsNullOrWhiteSpace(nuevaPass) || string.IsNullOrWhiteSpace(confirmarPass))
            {
                MostrarError("Los campos deben estar completos");
                return;
            }
            if (nuevaPass != confirmarPass)
            {
                MostrarError("Las contraseñas no coinciden");
                return;
            }

            using (var conexion = new DBAccess().GetConnection())
            {
                conexion.Open();

                string consulta = "UPDATE datos SET [password] = ? WHERE email = ?";
                OleDbCommand comando = new OleDbCommand(consulta, conexion);
                comando.Parameters.AddWithValue("?", nuevaPass);
                comando.Parameters.AddWithValue("?", correoVerificado);

                comando.ExecuteNonQuery();

                conexion.Close();
            }
            MessageBox.Show("Contraseña actualizada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void frmRecover_Load(object sender, EventArgs e)
        {

        }

        private void txtCorreo_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblError_Click(object sender, EventArgs e)
        {

        }
    }
}
