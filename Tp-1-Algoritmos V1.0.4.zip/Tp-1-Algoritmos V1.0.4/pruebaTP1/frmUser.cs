﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace pruebaTP1
{
    public partial class frmUser : Form
    {
        private User usuario; // campo privado para guardar el usuario logueado
        private string dniOriginal;

        // Constructor que recibe el objeto Usuario desde frmLogin
        public frmUser(User usuario)
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.KeyDown += frmUser_Keydown;

            this.usuario = usuario;
            this.dniOriginal = usuario.Dni; //guarda el DNI original aquí

            MostrarDatosUsuario();   // carga los datos en los controles
            HabilitarEdicion(false); // deshabilita edición al inicio
        }

        private void frmUser_Keydown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void MostrarDatosUsuario()
        {
            txtNombre.Text = usuario.Nombre;
            txtApellido.Text = usuario.Apellido;
            txtDni.Text = usuario.Dni;
            txtTelefono.Text = usuario.Telefono;
            txtEmail.Text = usuario.Email;
            txtPasswordUsuario.Text = usuario.Password;
        }

        private void HabilitarEdicion(bool habilitar)
        {
            txtNombre.ReadOnly = !habilitar;
            txtApellido.ReadOnly = !habilitar;
            txtDni.ReadOnly = true;
            txtTelefono.ReadOnly = !habilitar;
            txtEmail.ReadOnly = !habilitar;
            txtPasswordUsuario.ReadOnly = !habilitar;
            BtnSave.Enabled = habilitar;
            btnCancelar.Enabled = habilitar;
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellido.Text) ||
                string.IsNullOrWhiteSpace(txtDni.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) ||
                string.IsNullOrWhiteSpace(txtPasswordUsuario.Text))
            {
                MessageBox.Show("Todos los campos son obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!long.TryParse(txtDni.Text, out _) || !long.TryParse(txtTelefono.Text, out _))
            {
                MessageBox.Show("El DNI y el Teléfono deben ser numéricos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txtDni.Text.Length != 8)
            {
                MessageBox.Show("El DNI debe tener 8 dígitos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txtTelefono.Text.Length < 8 || txtTelefono.Text.Length > 10)
            {
                MessageBox.Show("El Teléfono debe tener entre 8 y 10 dígitos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            string email = txtEmail.Text.Trim();
            if (!email.Contains("@") || email.Length < 5)
            {
                MessageBox.Show("El email debe tener un formato válido (ej: usuario@dominio.com).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void ActualizarUserDesdeFrm()
        {
            usuario.Nombre = txtNombre.Text;
            usuario.Apellido = txtApellido.Text;
            //usuario.Dni = txtDni.Text;
            usuario.Telefono = txtTelefono.Text;
            usuario.Email = txtEmail.Text;
            usuario.Password = txtPasswordUsuario.Text;
        }

        private void ActualizarUserBD()
        {
            DBAccess db = new DBAccess();
            OleDbConnection conexion = db.GetConnection();
            conexion.Open();

            string consulta = "UPDATE datos SET " +
            "nombre = ?, " +
            "apellido = ?, " +
            "telefono = ?, " +
            "email = ?, " +
            "[password] = ? " +
            "WHERE dni = ?";

            OleDbCommand comando = new OleDbCommand(consulta, conexion);

            conexion.Open();
            // Agregar parámetros (en orden: nombre, apellido, telefono, email, password, dniOriginal)
            comando.Parameters.AddWithValue("?", usuario.Nombre);
            comando.Parameters.AddWithValue("?", usuario.Apellido);
            comando.Parameters.AddWithValue("?", usuario.Telefono);
            comando.Parameters.AddWithValue("?", usuario.Email);
            comando.Parameters.AddWithValue("?", usuario.Password);
            comando.Parameters.AddWithValue("?", dniOriginal);

            comando.ExecuteNonQuery();
            conexion.Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;

            ActualizarUserDesdeFrm();
            ActualizarUserBD();

            HabilitarEdicion(false);
            MessageBox.Show("Datos guardados correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnModificar_Click_1(object sender, EventArgs e)
        {
            HabilitarEdicion(true);
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            MostrarDatosUsuario();   
            HabilitarEdicion(false); 
        }
    }
}