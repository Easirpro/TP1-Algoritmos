﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace pruebaTP1
{
    public partial class frmAdmin : Form
    {
        bool esNuevo = false;
        string nombreUsuarioLogueado;
        string rolUsuarioLogueado;

        public frmAdmin(string nombreUsuario, string rolUsuario)
        {
            InitializeComponent();
            nombreUsuarioLogueado = nombreUsuario;
            rolUsuarioLogueado = rolUsuario;

            CargarUsuariosDesdeDB();
            cmbListUser.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            cmbListUser.SelectedIndex = 0;

            MostrarDatos();
            HabilitarEdicion(false);
        }
        private void CargarUsuariosDesdeDB()
        {
            using var conexion = new DBAccess().GetConnection();
            {
                conexion.Open();
                string consulta = "SELECT nombre FROM datos";
                OleDbCommand comando = new OleDbCommand(consulta, conexion);
                OleDbDataReader leer = comando.ExecuteReader();

                while (leer.Read())
                {
                    cmbListUser.Items.Add(leer["nombre"].ToString());
                }
            }
        }
        private void MostrarDatos()
        {
            if (cmbListUser.SelectedItem == null) return;
            string Nombre = cmbListUser.SelectedItem.ToString();

            using var conexion = new DBAccess().GetConnection();
            {
                conexion.Open();

                string consulta = "SELECT * FROM datos WHERE nombre = ?";
                OleDbCommand comando = new OleDbCommand(consulta, conexion);
                comando.Parameters.AddWithValue("?", Nombre);

                OleDbDataReader lector = comando.ExecuteReader();

                if (lector.Read())
                {
                    // Cargar datos básicos
                    txtNombre.Text = lector["nombre"].ToString();
                    txtApellido.Text = lector["apellido"].ToString();
                    txtDni.Text = lector["dni"].ToString();
                    txtTelefono.Text = lector["telefono"].ToString();
                    txtEmail.Text = lector["email"].ToString();

                    // Mostrar rol
                    string rol = lector["Rol"].ToString();
                    rdbAdmin.Checked = (rol == "Administrador");
                    rdbUser.Checked = (rol == "Usuario");

                    // Mostrar u ocultar la contraseña según el usuario logueado
                    if (Nombre == nombreUsuarioLogueado && rolUsuarioLogueado == rol)
                    {
                        txtPasswordUsuario.Text = lector["password"].ToString();
                        txtPasswordUsuario.ReadOnly = false;
                    }
                    else
                    {
                        txtPasswordUsuario.Text = "******";
                        txtPasswordUsuario.ReadOnly = true;
                    }
                }
            }
        }
        private void HabilitarEdicion(bool habilitar)
        {
            txtNombre.ReadOnly = !habilitar;
            txtApellido.ReadOnly = !habilitar;
            txtDni.ReadOnly = !habilitar;
            txtTelefono.ReadOnly = !habilitar;
            txtEmail.ReadOnly = !habilitar;
            rdbUser.Enabled = habilitar;
            rdbAdmin.Enabled = habilitar;
            BtnSave.Enabled = habilitar;
            btnCancelar.Enabled = habilitar;
            if (esNuevo)  txtPasswordUsuario.ReadOnly = false;
        }
        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtApellido.Text) ||
                string.IsNullOrWhiteSpace(txtDni.Text) || string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(txtPasswordUsuario.Text))
            {
                MessageBox.Show("Todos los campos son obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (!long.TryParse(txtDni.Text, out _) || !long.TryParse(txtTelefono.Text, out _))
            {
                MessageBox.Show("El DNI y el Teléfono deben ser numéricos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (txtDni.Text.Length != 8)
            {
                MessageBox.Show("El DNI debe tener 8 dígitos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (txtTelefono.Text.Length < 8 || txtTelefono.Text.Length > 10)
            {
                MessageBox.Show("El Teléfono debe tener entre 8 a 10 dígitos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            string email = txtEmail.Text.Trim();
            if (!email.Contains("@") || email.Length < 5)
            {
                MessageBox.Show("El email debe tener un formato válido (ej: usuario@dominio.com).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MostrarDatos();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos()) return;

            string Nombre = cmbListUser.SelectedItem.ToString();
            string rol = rdbAdmin.Checked ? "Administrador" : "Usuario";

            using var conexion = new DBAccess().GetConnection();
            {
                conexion.Open();
                if (esNuevo)
                {
                    //Chequear si DNI ya existe
                    string checkDni = "SELECT COUNT(*) FROM datos WHERE dni = ?";
                    OleDbCommand checkCmd = new OleDbCommand(checkDni, conexion);
                    checkCmd.Parameters.AddWithValue("?", txtDni.Text);
                    int count = (int)checkCmd.ExecuteScalar();
                    if (count > 0)
                    {
                        MessageBox.Show("Ya existe un usuario con ese DNI.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    //INSERT para usuario nuevo
                    string insertQuery = "INSERT INTO datos (nombre, apellido, dni, telefono, email, [password], Rol) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    OleDbCommand insertCmd = new OleDbCommand(insertQuery, conexion);
                    insertCmd.Parameters.AddWithValue("?", txtNombre.Text);
                    insertCmd.Parameters.AddWithValue("?", txtApellido.Text);
                    insertCmd.Parameters.AddWithValue("?", txtDni.Text);
                    insertCmd.Parameters.AddWithValue("?", txtTelefono.Text);
                    insertCmd.Parameters.AddWithValue("?", txtEmail.Text);
                    insertCmd.Parameters.AddWithValue("?", txtPasswordUsuario.Text);
                    insertCmd.Parameters.AddWithValue("?", rol);
                    insertCmd.ExecuteNonQuery();

                    // Actualizar ComboBox
                    cmbListUser.Items.Add(txtNombre.Text);
                    cmbListUser.SelectedItem = txtNombre.Text;
                    esNuevo = false;
                }
                else
                {
                    //UPDATE para usuario existente
                    string updateQuery = "UPDATE datos SET nombre = ?, apellido = ?, dni = ?, telefono = ?, email = ?, [password] = ?, Rol = ? WHERE nombre = ?";
                    OleDbCommand updateCmd = new OleDbCommand(updateQuery, conexion);

                    updateCmd.Parameters.AddWithValue("?", txtNombre.Text);
                    updateCmd.Parameters.AddWithValue("?", txtApellido.Text);
                    updateCmd.Parameters.AddWithValue("?", txtDni.Text);
                    updateCmd.Parameters.AddWithValue("?", txtTelefono.Text);
                    updateCmd.Parameters.AddWithValue("?", txtEmail.Text);
                    updateCmd.Parameters.AddWithValue("?", txtPasswordUsuario.Text);
                    updateCmd.Parameters.AddWithValue("?", rol);
                    updateCmd.Parameters.AddWithValue("?", Nombre);
                    updateCmd.ExecuteNonQuery();

                    // Si cambió el nombre, actualizar ComboBox
                    if (txtNombre.Text != Nombre)
                    {
                        int index = cmbListUser.Items.IndexOf(Nombre);
                        if (index != -1)
                        {
                            cmbListUser.Items[index] = txtNombre.Text;
                        }
                    }
                }
            }

            HabilitarEdicion(false);
            MessageBox.Show("Datos guardados correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            MostrarDatos();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            HabilitarEdicion(true);
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Limpiar campos para nuevo usuario
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtDni.Text = "";
            txtTelefono.Text = "";
            txtEmail.Text = "";
            txtPasswordUsuario.Text = "";
            rdbUser.Checked = true;
            rdbAdmin.Checked = false;
            HabilitarEdicion(true);
            esNuevo = true;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

            esNuevo = false;
            if (cmbListUser.Items.Count > 0) cmbListUser.SelectedIndex = 0;
            MostrarDatos();
            HabilitarEdicion(false);
        }

        private void lblTituloUsuario_Click(object sender, EventArgs e)
        {

        }
    }
}

