using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace pruebaTP1
{
    partial class Frmlogin : Form
    {

        public Frmlogin()
        {
            InitializeComponent();
            this.HelpButtonClicked += Helpbutton1_Click;
            this.AcceptButton = Btnenter;
        }

        private void Helpbutton1_Click(object? sender, EventArgs e)
        {
            MessageBox.Show("Ingrese su usuario y contrase�a para acceder.", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void lnkrecu_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmRecover form = new frmRecover();
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void Txtusuario_TextChanged_1(object? sender, EventArgs e)
        {
        }
        private void Frmlogin_Load(object sender, EventArgs e)
        {

        }
        private void Btnenter_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Txtusuario.Text) || string.IsNullOrWhiteSpace(Txtpass.Text))
            {
                MessageBox.Show("Usuario y contrase�a son obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (OleDbConnection conexion = new DBAccess().GetConnection())
            {

                string consulta = "SELECT * FROM datos WHERE nombre = ? AND password = ?";

                OleDbCommand comando = new OleDbCommand(consulta, conexion);

                comando.Parameters.AddWithValue("?", Txtusuario.Text);
                comando.Parameters.AddWithValue("?", Txtpass.Text);

                conexion.Open();
                OleDbDataAdapter adaptador = new OleDbDataAdapter(comando);
                DataTable datos = new DataTable();
                adaptador.Fill(datos);


                if (datos.Rows.Count == 1)
                {
                    string rol = datos.Rows[0]["Rol"].ToString();
                    string dni = datos.Rows[0]["dni"].ToString();

                    this.Hide();

                    if (rol == "Administrador")
                    {
                        frmAdmin form = new frmAdmin(Txtusuario.Text, rol);
                        form.ShowDialog();
                    }
                    else
                    {
                        frmUser form = new frmUser(Txtusuario.Text, dni);
                        form.ShowDialog();
                    }
                    this.Show();
                }
                else
                {
                    MessageBox.Show("Usuario o contrase�a incorrectos", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}