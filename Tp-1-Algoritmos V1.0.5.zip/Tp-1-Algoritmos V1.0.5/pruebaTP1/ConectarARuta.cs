﻿using System;
using System.Windows.Forms;
using System.Data.OleDb;
namespace pruebaTP1
{
    public class DBAccess
    {
        private OleDbConnection conexion;
        public OleDbConnection GetConnection()
        {
            string rutaDB = System.IO.Path.Combine(Application.StartupPath, "tp_algoritmo.accdb");
            string cadena = $"provider=Microsoft.ACE.OLEDB.12.0;Data Source={rutaDB}";
            conexion = new OleDbConnection(cadena);
            return conexion;
        }
    }
}


